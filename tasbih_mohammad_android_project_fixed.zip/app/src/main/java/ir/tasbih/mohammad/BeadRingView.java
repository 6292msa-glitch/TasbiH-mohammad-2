package ir.tasbih.mohammad;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** حلقهٔ تسبیح کاملاً با Canvas رسم می‌شود (بدون تصویر). کل ناحیه تپ‌پذیر است. */
public class BeadRingView extends View {
    public interface OnBeadTapListener { void onBeadTap(); }

    private final Paint beadFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint beadStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPath = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rope = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int count = 0;
    private int target = 33;
    private OnBeadTapListener listener;
    private static final int BEADS = 33;

    public BeadRingView(Context c) {
        super(c);
        beadStroke.setStyle(Paint.Style.STROKE);
        beadStroke.setStrokeWidth(2f);
        beadStroke.setColor(0xFF0B1B2B);
        rope.setStyle(Paint.Style.STROKE);
        rope.setStrokeWidth(8f);
        rope.setColor(0xFF1C3E5C);
        setOnClickListener(v -> { if (listener != null) listener.onBeadTap(); });
        setClickable(true);
    }

    public void setListener(OnBeadTapListener l){ listener = l; }
    public void setState(int c, int t){ count = c; target = t; invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth()/2f, cy = getHeight()/2f;
        float r = Math.min(cx, cy) * 0.78f;
        float beadR = Math.min(getWidth(), getHeight()) / (BEADS * 1.9f);
        if (beadR < 10f) beadR = 10f;

        canvas.drawCircle(cx, cy, r, rope);

        int filled = (target <= 0) ? 0 : (count % target == 0 && count > 0 ? target : count % target);
        for (int i = 0; i < BEADS; i++) {
            double ang = -Math.PI/2 + (2*Math.PI*i)/BEADS;
            float bx = cx + r*(float)Math.cos(ang);
            float by = cy + r*(float)Math.sin(ang);
            boolean lit = i < Math.min(filled, BEADS);
            if (lit) beadFill.setColor(0xFF40C4B0);          // فیروزه‌ای روشن
            else if (i == BEADS-1) beadFill.setColor(0xFFE8C46B); // مهرهٔ شاه‌مهره
            else beadFill.setColor(0xFFB5B5B5);              // خاکستری
            canvas.drawCircle(bx, by, beadR, beadFill);
            canvas.drawCircle(bx, by, beadR, beadStroke);
        }

        // آویز و مهرهٔ پایانی (سبک‌سازی گرافیکی، نه عکس واقعی)
        RectF t = new RectF(cx-8, cy+r-6, cx+8, cy+r+beadR*2.4f);
        beadFill.setColor(0xFFE8C46B);
        canvas.drawOval(t, beadFill);
        canvas.drawOval(t, beadStroke);
    }
}
