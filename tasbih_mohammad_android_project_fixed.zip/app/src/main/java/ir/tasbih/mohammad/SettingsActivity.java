package ir.tasbih.mohammad;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** تنظیم هدف قابل تغییر (حداقل ۱) و لرزش. رابط کاربری کاملاً برنامه‌ای. */
public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences p = getSharedPreferences("tasbih_prefs", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        root.setBackgroundColor(0xFF0B1B2B);

        TextView title = new TextView(this);
        title.setText(getString(R.string.target_label));
        title.setTextColor(0xFFF4FAFA);
        title.setTextSize(18f);

        final EditText et = new EditText(this);
        et.setHint(getString(R.string.target_hint));
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setTextColor(0xFFF4FAFA);
        et.setHintTextColor(0xFFA8C4C4);

        final CheckBox vib = new CheckBox(this);
        vib.setText(getString(R.string.vibration));
        vib.setTextColor(0xFFF4FAFA);
        vib.setChecked(p.getBoolean("vibrate", true));

        Button ok = new Button(this);
        ok.setText(getString(R.string.ok));
        ok.setOnClickListener(v -> {
            String raw = PersianDigits.toLatin(et.getText().toString()).trim();
            try {
                int t = Integer.parseInt(raw);
                if (t < 1) throw new NumberFormatException();
                p.edit().putInt("target", t).putBoolean("vibrate", vib.isChecked()).apply();
                Toast.makeText(this, getString(R.string.target_label) + ": " + PersianDigits.toFa(t),
                        Toast.LENGTH_SHORT).show();
                finish();
            } catch (Exception ex) {
                Toast.makeText(this, getString(R.string.invalid_number), Toast.LENGTH_SHORT).show();
            }
        });

        Button cancel = new Button(this);
        cancel.setText(getString(R.string.cancel));
        cancel.setOnClickListener(v -> finish());

        root.addView(title);
        root.addView(et, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(vib);
        root.addView(ok);
        root.addView(cancel);
        setContentView(root);
    }

    private int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
}
