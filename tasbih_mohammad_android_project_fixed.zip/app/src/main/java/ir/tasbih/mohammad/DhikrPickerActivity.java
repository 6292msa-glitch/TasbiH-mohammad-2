package ir.tasbih.mohammad;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** انتخاب ذکر از فهرست شروع (قرآنی، نه جامع). ذکر آزاد هم مجاز است. */
public class DhikrPickerActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(12), dp(12), dp(12));
        list.setBackgroundColor(0xFF0B1B2B);

        for (int i = 0; i < DhikrData.STARTER.length; i++) {
            final int idx = i;
            DhikrData.Entry e = DhikrData.STARTER[i];

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackgroundColor(0xFF132C42);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(10));
            card.setLayoutParams(lp);

            TextView t = new TextView(this);
            t.setText(e.title);
            t.setTextColor(0xFFF4FAFA);
            t.setTextSize(17f);
            t.setTypeface(null, Typeface.BOLD);

            TextView s = new TextView(this);
            s.setText(e.source + "\n" + e.note);
            s.setTextColor(0xFFA8C4C4);
            s.setTextSize(13f);

            card.addView(t); card.addView(s);
            card.setClickable(true);
            card.setOnClickListener(v -> {
                Intent out = new Intent();
                out.putExtra("dhikr_index", idx);
                setResult(RESULT_OK, out);
                finish();
            });
            list.addView(card);
        }

        // ذکر آزاد
        TextView free = new TextView(this);
        free.setText("ذکر آزاد (بدون متن ثابت)");
        free.setTextColor(0xFF7FE0D4);
        free.setTextSize(16f);
        free.setGravity(Gravity.CENTER);
        free.setPadding(dp(8), dp(8), dp(8), dp(8));
        free.setClickable(true);
        free.setOnClickListener(v -> {
            Intent out = new Intent();
            out.putExtra("dhikr_index", 0); // مدخل قرآنی پیش‌فرض؛ ذکر آزاد در ذهن کاربر
            setResult(RESULT_OK, out);
            finish();
        });
        list.addView(free);

        ScrollView sc = new ScrollView(this);
        sc.addView(list);
        setContentView(sc);
    }
    private int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
}
