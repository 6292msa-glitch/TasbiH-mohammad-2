package ir.tasbih.mohammad;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * همهٔ رابط کاربری به‌صورت برنامه‌ای ساخته می‌شود (بدون layout XML).
 * تسبیح با تپ در هر نقطهٔ ناحیهٔ آزاد (حلقهٔ مهره‌ها) شمرده می‌شود؛
 * دکمه‌ها ناحیهٔ کنترل جداگانه‌اند و شمارش را فعال نمی‌کنند.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "tasbih_prefs";
    private static final String K_COUNT = "count";
    private static final String K_TARGET = "target";
    private static final String K_DHIKR = "dhikr_index";
    private static final String K_VIBRATE = "vibrate";

    private SharedPreferences prefs;
    private BeadRingView ring;
    private TextView counterView, dhikrView, sourceView;
    private int count, target, dhikrIndex;
    private boolean vibrate;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        count = prefs.getInt(K_COUNT, 0);
        target = prefs.getInt(K_TARGET, 33);
        dhikrIndex = prefs.getInt(K_DHIKR, 0);
        vibrate = prefs.getBoolean(K_VIBRATE, true);

        int dark = 0xFF0B1B2B;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(dark);
        root.setClickable(true); // جلوگیری از عبور تپ به عناصر زیرین

        dhikrView = new TextView(this);
        dhikrView.setTextColor(0xFFF4FAFA);
        dhikrView.setTextSize(20f);
        dhikrView.setGravity(Gravity.CENTER);
        dhikrView.setPadding(dp(16), dp(16), dp(16), dp(4));

        sourceView = new TextView(this);
        sourceView.setTextColor(0xFFA8C4C4);
        sourceView.setTextSize(13f);
        sourceView.setGravity(Gravity.CENTER);
        sourceView.setPadding(dp(16), 0, dp(16), dp(8));

        counterView = new TextView(this);
        counterView.setTextColor(0xFF40C4B0);
        counterView.setTextSize(52f);
        counterView.setGravity(Gravity.CENTER);
        counterView.setPadding(0, 0, 0, dp(8));

        ring = new BeadRingView(this);
        ring.setListener(this::onBeadTap);
        ring.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(8), dp(8), dp(8), dp(16));

        Button btnReset = mkButton(getString(R.string.reset));
        Button btnDhikr = mkButton(getString(R.string.choose_dhikr));
        Button btnSet   = mkButton(getString(R.string.settings));
        btnReset.setOnClickListener(v -> { count = 0; save(); refresh(); });
        btnDhikr.setOnClickListener(v -> startActivityForResult(new Intent(this, DhikrPickerActivity.class), 1));
        btnSet.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        controls.addView(btnReset); controls.addView(btnDhikr); controls.addView(btnSet);

        root.addView(dhikrView);
        root.addView(sourceView);
        root.addView(counterView);
        root.addView(ring);
        root.addView(controls);
        setContentView(root);
        refresh();
    }

    private Button mkButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        btn.setLayoutParams(lp);
        return btn;
    }

    private void onBeadTap() {
        count++;
        if (vibrate) {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null) {
                if (Build.VERSION.SDK_INT >= 26)
                    vib.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE));
                else vib.vibrate(30);
            }
        }
        if (target > 0 && count == target) {
            android.widget.Toast.makeText(this, getString(R.string.completion_msg),
                    android.widget.Toast.LENGTH_SHORT).show();
        }
        save();
        refresh();
    }

    private void refresh() {
        counterView.setText(PersianDigits.toFa(count));
        DhikrData.Entry e = DhikrData.STARTER[dhikrIndex];
        dhikrView.setText(e.title);
        sourceView.setText(getString(R.string.source_label) + ": " + e.source);
        ring.setState(count, target);
    }

    private void save() {
        prefs.edit().putInt(K_COUNT, count).putInt(K_TARGET, target)
                .putInt(K_DHIKR, dhikrIndex).putBoolean(K_VIBRATE, vibrate).apply();
    }

    public void reloadFromPrefs() {
        target = prefs.getInt(K_TARGET, 33);
        dhikrIndex = prefs.getInt(K_DHIKR, 0);
        vibrate = prefs.getBoolean(K_VIBRATE, true);
        refresh();
    }

    @Override protected void onResume(){ super.onResume(); reloadFromPrefs(); }
    @Override protected void onPause(){ super.onPause(); save(); }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 1 && res == RESULT_OK && data != null) {
            dhikrIndex = data.getIntExtra("dhikr_index", dhikrIndex);
            save(); refresh();
        }
    }

    private int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
}
