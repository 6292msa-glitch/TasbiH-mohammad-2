package ir.tasbih.mohammad;

/** تبدیل اعداد لاتین به ارقام فارسی. */
public final class PersianDigits {
    private static final char[] FA = {'۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'};
    public static String toFa(long n) {
        String s = String.valueOf(n);
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= '0' && ch <= '9') b.append(FA[ch-'0']); else b.append(ch);
        }
        return b.toString();
    }
    /** تبدیل ارقام فارسی/عربی به لاتین برای ورودی کاربر */
    public static String toLatin(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= '۰' && ch <= '۹') b.append((char)('0'+(ch-'۰')));
            else if (ch >= '٠' && ch <= '٩') b.append((char)('0'+(ch-'٠')));
            else if (ch == '٬' || ch == ',') { /* جداکننده هزارگان: حذف */ }
            else b.append(ch);
        }
        return b.toString();
    }
    private PersianDigits(){}
}
