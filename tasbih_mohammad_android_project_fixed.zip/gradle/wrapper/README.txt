This project targets the Code on the Go IDE which runs Gradle directly.
If you build on PC, run `gradle wrapper` once to generate gradle-wrapper.jar.
